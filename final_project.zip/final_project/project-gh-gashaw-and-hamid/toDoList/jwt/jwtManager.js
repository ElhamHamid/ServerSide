"use strict";
/* eslint-disable */

const jwt=require('jsonwebtoken');

const secrete='KS-secrete';

class Jwtmanager {
    generete(data){
        let token= jwt.sign(data,secrete);
        return token;
    }

    verify(token){
        let data=jwt.verify(token,secrete);
        return data;
    }
}

module.exports=new Jwtmanager();