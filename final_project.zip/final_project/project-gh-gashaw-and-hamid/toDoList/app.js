"use strict";
/* eslint-disable */

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const usersRouter=require('./routes/users');
const MongoClient = require('mongodb').MongoClient;
const client = new MongoClient('mongodb+srv://gashu:38902@cluster0.04udb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', {useUnifiedTopology: true})
let connection;
const AauRouter=require('./aau/authoriAuthen');
const loginRouter=require('./routes/login');
const commentRouter=require('./routes/comment');
const likesRouter=require('./routes/likes');
const dislikesRouter=require('./routes/dislikes');



var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/', (req, res, next) => {
  if (!connection) { // connect to database
    console.log('connecting......');
    client.connect(function (err) {
      if(err) throw err;
      connection = client.db('todolist');
      req.db = connection;
      next();
    })
  } else { // 
    req.db = connection;
    next();
  }
});
app.use(AauRouter.authenticate);



app.use('/api/v1/users',usersRouter);
app.use('/api/v1/login',loginRouter);
app.use('/api/v1/comments',commentRouter);
app.use('/api/v1/likes',likesRouter);
app.use('/api/v1/dislikes',dislikesRouter);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

// module.exports = app;

app.listen(5000,function(){
  console.log("apps is running on port :5000");
})
