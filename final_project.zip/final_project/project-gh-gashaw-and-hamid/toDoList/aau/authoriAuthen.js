"use strict";
/* eslint-disable */

const jwtManager = require('../jwt/jwtManager');

class Authorization {
    authenticate(req, res, next) {

        if (req.url === '/api/v1/login') {
            next();
            return;
        }
        const tokens = req.headers.authorization;
        if (!tokens) {
            return res.json({ status: 'auth_error' });
        } else {
            const data = jwtManager.verify(tokens);
            if (!data) {
                return res.json({ status: 'auth_error' });
            }
            req.role = data.role
            req.id = data._id
            next();
        }
    }

    isUser(req, res, next) {

        if (req.role !== "user") {
            return res.json({ status: 'auth_error' });
        }
        next();

    };
    isAdmin(req, res, next) {


        if (req.role !== "Admin") {
            return res.json({ status: 'auth_error' });
        }
        next();

    };

    isAllowed(req, res, next) {

        if(req.db.collection('users').findOne({tag:{$in:[req.id]}})){
            next()
        }
    }


}

module.exports = new Authorization();