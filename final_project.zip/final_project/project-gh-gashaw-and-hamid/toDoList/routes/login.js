"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();
const Jwtmanager=require('../jwt/jwtManager');

router.post('/',function(req,res,next){
    req.db.collection('users').findOne({email:req.body.email})
    .then((data)=>{
        if(data){
            let temp={};
            temp.email=data.email;
            temp.role=data.role;
            temp._id=data._id;

            let token=Jwtmanager.generete(temp);
            res.json({status:"success",token:token});
        }else{
            res.json({status:"failed, invalid user"});
        }
    }).catch(err=>{
        res.json({status:"failed",err:err});
    })
})


module.exports=router;