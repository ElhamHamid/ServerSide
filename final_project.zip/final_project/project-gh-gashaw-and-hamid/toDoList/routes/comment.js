"use strict";
/* eslint-disable */
const express = require('express');
const router = express.Router();
const { ObjectID, ObjectId } = require('bson');
const AauRouter=require('../aau/authoriAuthen');

router.post('/:id/comment/:taskid',AauRouter.isUser, function (req, res, next) {
    req.db.collection('users').findOne({'_id':new ObjectID(req.params.id)})
    .then((user)=>{
        req.db.collection('users').findOne({'task.task_id':new ObjectID(req.params.taskid)})
        .then((data)=>{
          req.db.collection('users').findOne({tag:{$in:[req.id]}})
          .then(()=>{
              if(true){
                  let obj=req.body;
                  obj.user_id=req.id;
                  obj.task_id=new ObjectID(req.params.taskid);
                  obj.comment_time=new Date(Date.now());
                  console.log()
                  req.db.collection('users').updateOne({'task.task_id':new ObjectID(req.params.taskid)},{$push:{'task.$.comments':obj}})
                  .then(()=>{
                    //   console.log(comments)
                      res.json({status:'successs'})
                  }).catch((err)=>{
                    res.json({status:'faild'})
                  })
                //   console.log("terue");
              }
          }).catch((err)=>{
            res.json({status:"faild,not taged on this specific task"}) 
          })
        }).catch((err)=>{
            res.json({status:"faild, task is not found"}) 
        })
    
    }).catch((err)=>{
        res.json({status:"faild, user not found"})
    })
})

router.get('/:id/top5',AauRouter.isAdmin,function(req,res){
  req.db.collection('users').findOne({role: "Admin"})
  .then((data)=>{
    let arr = data.task
    console.log(arr)
    arr.sort((a, b)=>a["comments"].length > b["comments"].length ? 1 : -1)
    arr.length = 3;
    res.json({status: 'success', result: arr})
  }).catch(err=>{
    res.json({status:"Faild",err:err})
  })
});

router.delete('/:id/todos/:taskid',AauRouter.isUser, AauRouter.isAllowed ,function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) })
    .then((data) => {
      if (data) {
        req.db.collection('users').updateOne({ 'task.task_id': new ObjectID(req.params.taskid) }, { $pull: { "task.comments": { 'task_id': new ObjectID(req.params.taskid) } } })
          .then(() => {
            res.json({ status: "success, deleted successfully" });
          }).catch(() => {
            res.json({ status: "faild to update todo list" });
          })
      }
    }).catch((err) => {
      res.json({ status: "Faild", err: err });
    })
})


module.exports = router;