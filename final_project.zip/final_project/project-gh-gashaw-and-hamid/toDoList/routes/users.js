"use strict";
/* eslint-disable */

const express = require('express');
const router = express.Router();
const AauRouter = require('../aau/authoriAuthen');
const { ObjectID } = require('bson');




router.get('/', AauRouter.isAdmin, (req, res) => {
  req.db.collection('users').find({role: "user"}).limit(5).toArray()
    .then(data => {
      res.json({ status: 'success', data: data })
    }).catch(err => {
      res.json({ status: 'fail' });
    })
})


router.get('/:id/user', function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) }, { projection: { 'title': 1, 'task': 1, 'shares_no': 1, 'likes': 1, 'dislikes': 1, 'comments': 1 } })
    .then((data) => {
      res.json({ status: "success", result: data });
    }).catch(err => {
      res.json({ status: "Faild", err: err })
    })
});

router.get('/:id/sort', function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) }, { projection: { "task": 1 } })
    .then((data) => {
      let taskArr = data.task
      taskArr.sort((x, y) => x.creation_date > y.creation_date ? -1 : 1)
      res.json({ status: "success", result: taskArr });
    }).catch(err => {
      res.json({ status: "Faild", err: err })
    })
});



router.get('/:id/todos', AauRouter.isUser, function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) }, { projection: { '_id': 0, 'task': 1, 'shares_no': 1, 'likes': 1, 'dislikes': 1, 'comments': 1 } })
    .then((data) => {
      res.json({ status: "success", result: data });
    }).catch(err => {
      res.json({ status: "Faild", err: err })
    })
});

router.get('/:id/filter', AauRouter.isAdmin, (req, res)=> {
  req.db.collection('users').findOne({"_id": new ObjectID(req.params.id)}, {projection: {"task": 1, "_id": 0}})
  .then(data => {
    console.log(data.task)
    let arr = data.task
    let filtered = arr.filter(elem =>{  if(elem.status === "incomplete") return elem})
    res.json({status: 'success', result: filtered})
  }).catch(err => {
    res.json({status: 'fail'})
  })
})


router.get('/top3',AauRouter.isAdmin,function(req,res){
  req.db.collection('users').find({role: "user"}).sort({no_of_incomplete_tasks: -1}).limit(3).toArray()
  .then((data)=>{
    res.json({status:"success",result:data});
  }).catch(err=>{
    res.json({status:"Faild",err:err})
  })
});



router.post('/:id/todo', AauRouter.isUser, function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) })
    .then((data) => {
      if (data) {
        let temp = req.body;
        temp.task_id = ObjectID();
        temp.creation_date = new Date(Date.now());
        req.db.collection('users').updateOne(data, { $push: { task: temp } })
          .then(() => {
            res.json({ status: "success" })
          }).catch(() => {
            res.json({ status: "faild to create new todo list" });
          })
      }
    }).catch(err => {
      res.json({ status: "Faild", err: err })
    })
});

router.post('/:id/share/:taskid', AauRouter.isUser, function (req, res, next) {
  req.db.collection('users').findOne({
    '_id': new ObjectID(req.params.id),
    'task.task_id': new ObjectID(req.params.taskid),
    'task.$.tag': { $nin: [new ObjectID(req.body.user_id)] }
  }).then(() => {
    req.db.collection('users').updateOne({ 'task.task_id': new ObjectID(req.params.taskid) }, { $push: { 'task.$.tag': new ObjectID(req.body.user_id) } })
      .then(() => {
        res.json({ status: "success" })
      }).catch(err => {
        res.json({ status: "faild", err: err })
      })
  }).catch(err => {
    res.json({ status: "Faild", err: err })
  })
});


router.put('/:id/todos/:taskid', AauRouter.isUser, function (req, res) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) })
    .then((data) => {
      if (data) {
        req.db.collection('users').updateOne({ 'task.task_id': new ObjectID(req.params.taskid) }, { $set: { 'task.$.status': "complete", 'task.$.creation_date': new Date(Date.now()) } })
          .then(() => {
            res.json({ status: "success, updated successfully" });
          }).catch(() => {
            res.json({ status: "faild to update todo list" });
          })
      }
    }).catch((err) => {
      res.json({ status: "Faild", err: err });
    })
});

router.delete('/:id/todos/:taskid', function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) })
    .then((data) => {
      if (data) {
        req.db.collection('users').updateOne({ 'task.task_id': new ObjectID(req.params.taskid) }, { $pull: { task: { 'task_id': new ObjectID(req.params.taskid) } } })
          .then(() => {
            res.json({ status: "success, deleted successfully" });
          }).catch(() => {
            res.json({ status: "faild to update todo list" });
          })
      }
    }).catch((err) => {
      res.json({ status: "Faild", err: err });
    })
})




module.exports = router