"use strict";
/* eslint-disable */
const express = require('express');
const router = express.Router();
const { ObjectID, ObjectId } = require('bson');
const AauRouter=require('../aau/authoriAuthen');

router.get('/:id/sort', function (req, res, next) {
  req.db.collection('users').findOne({ '_id': new ObjectID(req.params.id) }, {projection: {"task": 1}})
    .then((data) => {
      let taskArr = data.task
      taskArr.sort((x, y) => x.dislikes.length > y.dislikes.length ? 1 : -1)
      res.json({ status: "success", result: taskArr });
    }).catch(err => {
      res.json({ status: "Faild", err: err })
    })
});

router.post('/:id/dislike/:taskid',AauRouter.isUser, function (req, res, next) {
    req.db.collection('users').findOne({'_id':new ObjectID(req.params.id)})
    .then((user)=>{
        req.db.collection('users').findOne({'task.task_id':new ObjectID(req.params.taskid)})
        .then((data)=>{
          req.db.collection('users').findOne({tag:{$in:[req.id]}})
          .then(()=>{
              if(true){
                  let obj={}
                  obj.user_id=req.id;
                  obj.task_id=new ObjectID(req.params.taskid);
                  obj.disliked_time=new Date(Date.now());
                  console.log()
                  req.db.collection('users').updateOne({'task.task_id':new ObjectID(req.params.taskid)},{$push:{'task.$.dislikes':obj}})
                  .then(()=>{
                    //   console.log(comments)
                      res.json({status:'successs'})
                  }).catch((err)=>{
                    res.json({status:'faild'})
                  })
                //   console.log("terue");
              }
          }).catch((err)=>{
            res.json({status:"faild,not taged on this specific task"}) 
          })
        }).catch((err)=>{
            res.json({status:"faild, task is not found"}) 
        })
    
    }).catch((err)=>{
        res.json({status:"faild, user not found"})
    })
})




module.exports = router;