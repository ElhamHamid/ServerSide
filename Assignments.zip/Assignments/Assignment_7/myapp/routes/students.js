"use strict";
/* eslint-disable */

const express=require('express');
const { ObjectID } = require('mongodb');
const { route } = require('./lectures');
const router=express.Router();

router.get('/',function(req,res,next){
    req.db.collection('students').find().toArray().then(function(data){
        res.json({status:'sucess',data:data});
    }).catch(err=>{
        res.json({status:'failed'});
    })
})

router.get('/:id',function(req,res,next){
  
  
    req.db.collection('students').findOne({_id:new ObjectID(req.params.id)}).then(function(data){
        res.json({status:'sucess',data:data});
    }).catch(err=>{
        res.json({status:'failed'});
    })
})

router.get('/search',function(req,res,next){
    req.db.collection('students').findOne({fname:req.query.fname}).then(function(data){
        res.json({status:'sucess',data:data});
    }).catch(err=>{
        res.json({status:'failed'});
    })
})


router.post('/',function(req,res,next){
    req.db.collection('students').insertOne(req.body).then(function(){
        res.json({status:'sucess'});
    }).catch(err=>{
        res.json({status:'failed'});
    })
})

router.delete('/:id',function(req,res,necxt){
    req.db.collection('students').removeOne({_id:new ObjectID(req.params.id)}).then(function(){
        res.json({status:'sucess'});
    }).catch(err=>{
        res.json({status:'failed'});
    })
})








module.exports=router;