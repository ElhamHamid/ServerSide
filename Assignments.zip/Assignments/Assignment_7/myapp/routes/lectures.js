"use strict";
/* eslint-disable */

const express=require('express');
const { ObjectID } = require('mongodb');
const router=express.Router();

router.get('/',function(req,res,next){
    req.db.collection('lectures').find().toArray(function(err,data){
        if(err) res.end();
        res.json({status:'sucess',data:data});
    })
})

router.get('/:id',function(req,res,next){
    req.db.collection('lectures').findOne({_id:new ObjectID(req.params.id)}).then(function(data){
        res.json({status:'sucess',data:data});
    }).catch(err=>{
        res.json({ststus:'failed'});
    })
      
})

router.post('/',function(req,res,next){
    req.db.collection('lectures').insertOne(req.body).then(function(){
        res.json({status:'sucess'});
    }).catch(err=>{
        res.json({ststus:'failed'});
    })
})

router.delete('/:id',function(req,res,next){
    req.db.collection('lectures').removeOne({_id:new ObjectID(req.params.id)}).then(function(){
        res.json({status:'sucess'});
    }).catch(err=>{
        res.json({ststus:'failed'});
    })
})


module.exports=router;
