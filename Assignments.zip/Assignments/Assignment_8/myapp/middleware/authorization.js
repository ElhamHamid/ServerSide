"use strict";
/* eslint-disable */

let JwtManager = require('../jws/jwsManaager');

class Authorization {
    authenticate(req,res,next){
        if(req.url==='/auth'){
            next();
            return;
        }
        // console.log("am here")
            const header=req.headers.authorization;
            if(!header){
                res.json({ status: 'authentication error' });
            }else{
                let data=JwtManager.verify(header);
                if(!data){
                    res.json({ status: 'authentication error' }); 
                }
                next();
            }
       
    }
}

module.exports= new Authorization();

