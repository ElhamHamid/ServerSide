"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();

router.get('/',function(req,res,next){
    req.db.collection('students').find().project({'fname':1,'lname':1,'email':1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success",data:data});
    })
})








module.exports=router;