"use strict";
/* eslint-disable */

const express = require('express');
const router = express.Router();
let JwtManager = require('../jws/jwsManaager')

router.post('/', function (req, res, next) {
    let email = req.body.email;
    let password = req.body.password
    req.db.collection('students').findOne({ email: email }, function (err, data) {
        if (err) throw err;
        if (data) {
            let temp = {
                email,
                password
            };

            let token = JwtManager.generate(temp);
            res.json({ status: 'success', token: token });


        } else {
            res.json({ status: 'authentication error' });
        }
    })
})


module.exports = router;
