"use strict";
/* eslint-disable */

const dns = require('dns');

function myfunc(hostname) {
    dns.resolve4(hostname, { ttl: true }, (err, address) => {
        if (err) {
            console.log(err);
        } else {
            console.log(address)
        }
    })
}

myfunc('www.miu.edu');
myfunc('www.google.com');
myfunc('www.craftsoftware.com');
myfunc('www.elhamhamid.github.io/');