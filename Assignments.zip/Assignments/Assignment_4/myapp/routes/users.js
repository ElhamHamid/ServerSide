"use strict";
/* eslint-disable */

var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('Respond From User');
});

module.exports = router;
