"use strict";
/* eslint-disable */

var express = require('express');
var router = express.Router();

/* GET products listing. */
router.get('/', function(req, res, next) {
  res.send('Respond From product ');
});

module.exports = router;