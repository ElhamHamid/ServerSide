"use strict";
/* eslint-disable */

const fs=require('fs');
const { read } = require('fs/promises');
const zlib=require('zlib');
const gzip=zlib.createGzip();
const gunzip=zlib.createGunzip()

// const readable=fs.createReadStream(__dirname+'/largedata.txt',{highWaterMark:16*1024});
// const compressedFile=fs.createWriteStream(__dirname+'/destination.txt.gz');
// readable.pipe(gzip).pipe(compressedFile);

const readable2=fs.createReadStream(__dirname+'/destination.txt.gz',{highWaterMark:16*1024});
const destinationUnZipedFile=fs.createWriteStream(__dirname+'/unziped.txt');

readable2.pipe(gunzip).pipe(destinationUnZipedFile);


