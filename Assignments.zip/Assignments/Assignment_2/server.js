"use strict";
/* eslint-disable */

const http=require('http');
const fs=require('fs');
const server=http.createServer();

server.on('request',function(req,res){
    let readable=fs.createReadStream(__dirname+'/largedata.txt',{highWaterMark: 16*1024});
    readable.pipe(res);
})

server.listen(5000);

