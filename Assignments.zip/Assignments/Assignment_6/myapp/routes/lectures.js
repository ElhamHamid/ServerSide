"use strict";
/* eslint-disable */

var express = require('express');
var router = express.Router();

//   GET   /lectures/find 
router.get('/find', function (req, res, next) {
  
  req.db.collection('lectures').find().toArray(function(err,data){
    if(err) throw err;
    console.log(data);
    res.json(data);
  })


});


//   GET   /lectures/findOne
router.get('/FindOne/:course', function (req, res, next){
  let value=req.params.course
  req.db.collection('lectures').findOne({'course':`${value}`},function(err,data){
    if(err) throw err;
    console.log(data);
    res.json(data);
  });

})
 


//   POST /lectures/add
router.post('/add', function (req, res, next) {

  let value=req.body
  req.db.collection('lectures').insertOne(value,function(err,data){
    if(err) throw err;
    console.log(` inserted : ${JSON.stringify(value)}`);
    res.json("successfully submitted !!");
  });

});


//   DELETE /lectures/delete
router.delete('/delete/:one', function (req, res, next) {
  let value=req.params.one
  req.db.collection('lectures').deleteOne({'course':`${value}`},function(err,data){
    if(err) throw err;
    console.log(` Deleted : ${JSON.stringify(value)}`);
    res.json("successfully Deleted !!");
  });
});



module.exports = router;