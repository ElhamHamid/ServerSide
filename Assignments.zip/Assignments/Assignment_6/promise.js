"use strict";
/* eslint-disable */

const isPrime=require('./isprime');



const isPrimePromise=function(num){
    return new Promise(function(resolve,reject){
        let result=isPrime(num);
        setTimeout(()=>{
            resolve(result);
        },500);
    })
}

isPrimePromise(101)
.then(data=>console.log(data))
.catch(data=>console.log(data));