"use strict";
/* eslint-disable */

const http=require('http');
const server=http.createServer();
const fs=require('fs');
const url=require('url')

server.on('request',function(req,res){
    const writable=fs.createWriteStream('./testfile.txt')
    if(req.url==='/'){
        fs.createReadStream('./index.html').pipe(res);
    } else if(req.url==='/info'){
        req.pipe(writable);
        // fs.createReadStream('./index.html').pipe(res);
    //     let body=[];
    //  req.on('data',function(data){
    //      body.push(data);
    //  })
    //  req.on('end',function(){
    //      let bodybuff=Buffer.concat(body).toString();
    //      console.log(bodybuff);
    //      writable.write(bodybuff)
    //      res.end("receved");
    //  })

    }
});

server.listen(3000,function(){
    console.log("server is running on port: 3000");
})


