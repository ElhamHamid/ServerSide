"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();


router.get('/',function(req,res,next){
    let obj={
        "courseName":"nodeJs",
        "couseNumber":"CS477"
    }

    res.write(JSON.stringify(obj));
    res.end()
});

module.exports=router;