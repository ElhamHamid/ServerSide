"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();



router.post('/:fname',function(req,res,next){
//    console.log(req.body);
const bodyObj=req.params.fname;
console.log(bodyObj);
    res.write("Successfully Recived");
        res.end();
});

module.exports = router;