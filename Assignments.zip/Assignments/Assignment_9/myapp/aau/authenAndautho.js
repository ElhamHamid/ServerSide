"use strict";
/* eslint-disable */

const JwtManager=require('../jwt/jwtManeger');

class Aau {
    autentiautora(req,res,next){
        if(req.url==='/api/v1/logins' || req.url==='/api/v1/signups'){
            return next();
        }
        
        let token=req.headers.authentication;
        if(!token){
            res.json({status:"authentication error"});
        }else{
            let data=JwtManager.verify(token);
            if(!data){
                res.json({status:"authentication error"}); 
            }
            req.role=data.role;
        }   

        next();

    }
    isLibrarian(req,res,next){
        if(req.role!=='librarian'){
            return res.json({status:"failed, invalid user"});
        }
        next();
    }

    isStudent(req,res,next){
        if(req.role!=='student'){
            return res.json({status:"failed, invalid user"});
        }
        next();
    }

    checkBook(req,res,next){
        if(req.method===POST || req.method===PUT || req.method===DELETE){
            if(req.role!=='librarian'){
                return res.json({status:"failed, invalid user"});
            }
        }
        next();
    }
}


module.exports=new Aau();
