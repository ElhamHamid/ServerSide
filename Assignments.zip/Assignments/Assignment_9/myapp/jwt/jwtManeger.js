"use strict";
/* eslint-disable */

const jwt=require('jsonwebtoken');
let secret='hamid-said';

class JwtManager {
    generate(data){
        let token=jwt.sign(data,secret);
        return token;
    }

    verify(token){
        let data=jwt.verify(token,secret);
        return data;
    }
}

module.exports=new JwtManager();