"use strict";
/* eslint-disable */

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
let MongoClient = require('mongodb').MongoClient;
let client = new MongoClient('mongodb+srv://hamid:test143@cluster0.ixbz2.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', { useUnifiedTopology: true });
let connection;
let loginRouter=require('./routes/logIn');
let authoautheriRouter=require('./aau/authenAndautho');
let booksRouter=require('./routes/books');
let studentsRouter=require('./routes/students');
let librarianRouter=require('./routes/librarian');
let signupRouter=require('./routes/signup');


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(function (req, res, next) {
  if (!connection) {
    console.log("connecting....")
    client.connect(function (err) {
      if (err) throw err;
      connection = client.db('lab9');
      req.db = connection;
      next();
    })
  } else {
    req.db = connection;
    next();
  }
});
app.use(authoautheriRouter.autentiautora);

app.use('/api/v1/logins',loginRouter);
app.use('/api/v1/signups',signupRouter);

app.use('/api/v1/books',booksRouter);
app.use('/api/v1/students',studentsRouter);
app.use('/api/v1/librarians',librarianRouter);




// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

// module.exports = app;
app.listen(9000,function(){
  console.log("app is runninng on port: 9000");
})