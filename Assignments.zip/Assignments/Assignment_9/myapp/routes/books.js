"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();
const { ObjectID } = require('bson');

router.get('/',function(req,res,next){
    req.db.collection('books').find().project({"Book-title":1,"author":1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success",data:data});
       
    })
})

router.get('/:key',function(req,res,next){
    req.db.collection('books').find({'keyword':{$eq:req.params.key}}).project({"Book-title":1,"author":1,"borrowed_by":1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success",data:data});
    })
})
router.get('/borrowed',function(req,res,next){
    req.db.collection('books').find({'borrowe_by.length':{$ne:0}}).project({"Book-title":1,"author":1,"borrowed_by":1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success",data:data});
    })
})
router.post('/:id/borrow',function(req,res,next){
    let id=req.params.id;
    let borrower=req.body;
    req.db.collection('books').findone({_id:new ObjectID(id)},function(err,data){
        if(err) throw err;
        if(data){
            data['borrowed_by'].push(borrower);
            res.json({status:"success"});
        }else{
            res.json({status:"invalid book id"});
        }
    })
})

router.post('/',function(req,res,next){
    req.db.collection('books').insertOne(req.body,function(err){
        if(err) throw err;
        res.json({status:"success"});
    })
})

router.put('/:id',function(req,res,next){
    let id=req.params.id;
    let Booktitle=req.body['Book-title'];
    let authorfname=req.body.author.fname;
    let authorlname=req.body.author.lname;
    req.db.collection('books').update({_id:new ObjectID(id)},{$set:{"Book-title":Booktitle,"author.fname":authorfname,"author.lname":authorlname}},function(err){
        if(err) throw err;
        res.json({status:"success"});
    })
})

router.delete('/:id',function(req,res,next){
    let id=req.params.id;
    req.db.collection('books').removeOne({_id:new ObjectID(id)},function(err){
        if(err) throw err;
        res.json({status:"success"});
    })
})



module.exports=router;
