"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();
const { ObjectID } = require('bson');

router.get('/',function(req,res,next){
    req.db.collection('students').find().project({"fname":1,"lname":1,"email":1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success",data:data});
    })
})

// router.post('/',function(req,res,next){
//     req.db.collection('students').insertOne(req.body,function(err){
//         if(err) throw err;
//         res.json({status:"success"});
//     })
// })

router.put('/:id',function(req,res,next){
    let id=req.params.id;
    let fname=req.body.fname;
    let lname=req.body.lname;
    let email=req.body.email;
    req.db.collection('students').update({_id:new ObjectID(id)},{$set:{"fname":fname,"lname":lname,"email":email}},function(err){
        if(err) throw err;
        res.json({status:"success"});
    })
})

router.delete('/:id',function(req,res,next){
    let id=req.params.id;
    req.db.collection('students').removeOne({_id:new ObjectID(id)},function(err){
        if(err) throw err;
        res.json({status:"success"});
    })
})


module.exports=router;