"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();
const JwtManager=require('../jwt/jwtManeger');
const  bcrypt = require('bcryptjs');

router.post('/',function(req,res,next){
    let email=req.body.email;
    let password=req.body.password;
    let role=req.body.role; 
    
    if(role==='librarian'){
        req.db.collection('librarian').findOne({'email':email,'password':password},function(err,data){
            if(err) throw err;
            if(data){
                let temp={
                    email,
                    password,
                    role
                };
                let token=JwtManager.generate(temp);
                res.json({status:"success", token:token});
            }else{
                res.json({status:"invalid_user"});
            }
        })
    }
    if(role==='student'){
        req.db.collection('students').findOne({'email':email,'password':password},function(err,data){
            if(err) throw err;
            if(data){
                let temp={
                    email,
                    password,
                    role
                };
                let token=JwtManager.generate(temp);
                res.json({status:"success", token:token});
            }else{
                res.json({status:"invalid_user"});
            }
        })
    } else{
        res.json({status:"login faild, please sign up!!"});
    }

})


module.exports=router;
