"use strict";
/* eslint-disable */

const express = require('express');
const { render } = require('jade');
const router = express.Router();
const bcrypt = require('bcryptjs');

router.get('/', function (req, res, next) {
    let fname = req.body.fname;
    let lname = req.body.lname
    let email = req.body.email
    let role = req.body.role;
    let password = req.body.password;
    let hashedpassword = bcrypt.hashSync(password, 12);

    if (role === 'student') {
        req.db.collection('students').findOne({ 'email': email, 'password': password }, function (err, data) {
            if (err) throw err;
            if (!data) {
                let temp = {
                    fname,
                    lname,
                    email,
                    password: hashedpassword,
                    role
                };
                req.db.collection('students').insertOne(temp, function (err) {
                    if (err) throw err;
                    res.json({ status: "success" });
                })

            } else {
                res.json({ status: "user already exist" });
            }
        })
    }
    if (role === 'librarian') {
        req.db.collection('librarian').findOne({ 'email': email, 'password': password }, function (err, data) {
            if (err) throw err;
            if (!data) {
                let temp = {
                    fname,
                    lname,
                    email,
                    password: hashedpassword,
                    role
                };
                req.db.collection('librarian').insertOne(temp, function (err) {
                    if (err) throw err;
                    res.json({ status: "success" });
                })

            }else {
                res.json({ status: "user already exist" });
            }
        })
    }
})

module.exports = router;