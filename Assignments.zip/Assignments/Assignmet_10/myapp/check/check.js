"use strict";
/* eslint-disable */


 let checkValidity=function(req,res,next){
    let body=req.body;
    if(body.id!=="" && body.name!=="" && body.course!=="" && body.grade!=="" ){
      return next();
    }else{
        res.json({status:"faild, please insert all the required field"});
    }
  }


  module.exports=checkValidity;