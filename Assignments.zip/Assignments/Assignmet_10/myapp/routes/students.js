"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();
const { ObjectID } = require('bson');
const checkValidity = require('../check/check');


router.get('/',function(req,res,next){
    req.db.collection('students1').find().project({"name":1,"course":1,"grade":1}).toArray()
    .then(data=>{
        res.json({status:"success",data:data});
    }).catch(err=>console.log(err));
})
router.get('/:id',function(req,res,next){
    let id=req.params.id;
    req.db.collection('students1').findOne({_id:new ObjectID(id)})
    .then(data=>{
        res.json({status:"success",data:data});
    }).catch(err=>console.log(err));
})

router.post('/',checkValidity,function(req,res){
    req.db.collection('students1').insertOne(req.body)
    .then(()=>{
        res.json({status:"success"});
    }).catch(err=>console.log(err));
})

router.delete('/:id',function(req,res){
    req.db.collection('students1').removeOne({_id:new ObjectID(req.params.id)})
    .then(()=>{
        res.json({status:"success"}); 
    }).catch(err=>console.log(err));
})

module.exports=router;