"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();

router.get('/2',function(req,res){
    req.db.collection('resturants').find({$and:[{cuisine:{$ne:"American"}},{"gardes.score":{$gt:70}}]}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success", result:data});
    });
})

router.get('/3',function(req,res){
    req.db.collection('resturants').find({name:{$regex:'^wil'}}).project({name:1,district:1,cuisine:1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success", result:data});
    });
})

router.get('/4',function(req,res){
    req.db.collection('resturants').find({name:{$regex:'reg'}}).project({name:1,district:1,cuisine:1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success", result:data});
    });
})

router.get('/5',function(req,res){
    req.db.collection('resturants').find({$and:[{district:'Bronx'},{cuisine:{$in:['American','Chinese']}}]}).toArray()
    .then(data=>{
        res.json({status:"success", result:data});
    }).catch(err=>console.log(err));
})

router.get('/6',function(req,res){
    req.db.collection('resturants').find({district:{$in:["Staten","Island","Queens","Bronx","Brooklyn"]}}).project({name:1,district:1,cuisine:1}).toArray()
    .then(data=>{
        res.json({status:"success", result:data}); 
    }).catch(err=>console.log(err));
})

router.get('/7',function(req,res){
    req.db.collection('resturants').find({district:{$nin:["Staten","Island","Queens","Bronx","Brooklyn"]}}).project({name:1,district:1,cuisine:1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success", result:data});
    });
})

router.get('/8',function(req,res){
    req.db.collection('resturants').find({"grades.score":{$lte:10}}).project({name:1,district:1,cuisine:1}).toArray(function(err,data){
        if(err) throw err;
        res.json({status:"success", result:data});
    });
})

module.exports=router;

