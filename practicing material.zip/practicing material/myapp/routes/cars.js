"use strict";
/* eslint-disable */
const { ObjectID } = require('bson');
const express=require('express');
const router=express.Router();

router.get('/',function(req,res,next){
    req.db.collection('cars').find({status:{$eq:1}}).project({"brand":1,"type":1,"year":1,"status":1,"rate_per_day":1}).toArray()
    .then((data)=>{
        res.json({status:"success",result:data});
    }).catch((err)=>console.log(err))
})

router.post('/:id/reserve',function(req,res,next){
    req.db.collection('cars').findOne({'_id':new ObjectID(req.params.id)})
    .then((data)=>{
        console.log(data)
        let start=data['rental_details']['rental_details.length'-1]['end_mileage'];
        console.log(start)
        let payload=req.body;
        payload.start_mileage=start;
        payload.reservation_id=ObjectID();
        req.db.collection('cars').updateOne({'_id':new ObjectID(req.params.id)},{$push:{'rental_details':payload}})
        .then(()=>{
            res.json({status:"success",reservation_id:payload.reservation_id});
        }).catch((err)=>console.log(err))
    }).catch(err=>console.log(err));
})

router.put('/',function(req,res,next){
    
})





module.exports=router;